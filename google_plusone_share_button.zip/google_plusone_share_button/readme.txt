=== Add Google +1 (Plus one) social share Button ===
Contributors: Pankaj Jha
Plugin Site: http://onlinewebapplication.com/
Tags: Google +1, Google plus one, Google social share, Google +1 button
Requires at least: 2.8+
Tested up to: 3.2
Stable tag: 2.0.0

== Description ==
<br />
[Author Site](http://onlinewebapplication.com)|
[Plugin Home Page](http://onlinewebapplication.com/2011/10/google-social-wordpress-plugin.html)
<br />
<br />
This plugin shows google +1 (plus one) social share button in three different position and styles.

* Automatically display Google +1 button Above the post, below the post, both above and below or floating left side of post.

* Option to select the different button style (Standard, small, medium and Tall)

* Javascript is by default loaded in footer (recommended). 

* Left side floating option can be configured. The top and left spacing can be configured according to your site layout. Also the floating position of button can be fixed or absolute. All can be easily configured.

* Option to manually display the share box at any position.


== Installation ==

Very easy to install, similar to rest of the plugins.

1. Download and unzip the plugin .zip.<br />
2. Copy the unzipped folder in your Plugins directory under wordpress installation. (wp-content/plugins)<br />
3. Activate the plugin through the plugin window in the admin panel.<br />
4. Configure the settings through Settings->TWG Social Share in the admin panel.


== Screenshots ==
You can Check Screen Shots on my website :<br />
[Twitter Facebook Google Plusone Social Share](http://onlinewebapplication.com/2011/10/google-social-wordpress-plugin.html)<br />

